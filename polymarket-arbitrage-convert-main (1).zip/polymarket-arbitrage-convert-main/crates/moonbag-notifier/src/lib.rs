//! Moonbag Notifier - Telegram notifications
//!
//! TODO: Implement Telegram API client

pub mod telegram;

pub use telegram::TelegramNotifier;
