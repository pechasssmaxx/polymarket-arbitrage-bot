//! Moonbag Queue - Job queue for opportunities
//!
//! TODO: Implement file-based queue

pub mod file_queue;

pub use file_queue::FileQueue;
